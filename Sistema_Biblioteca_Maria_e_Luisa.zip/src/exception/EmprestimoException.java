package exception;

public class EmprestimoException extends Exception  {
    public EmprestimoException(String mensagem){
        super(mensagem);
    }
}
